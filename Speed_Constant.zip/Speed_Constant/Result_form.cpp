#include "Result_form.h"

System::Void SpeedConstant::Result_form::button_OK_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
	return System::Void();
}
